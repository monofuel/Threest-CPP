#ifdef __AVR_ARCH__
//suck it
#ifndef NULL
#define NULL null
#endif
#endif

#ifndef	HASHMAP_H
#define HASHMAP_H

template<typename T>
class hash_map {



};


#endif
